package DomainValue;

public class nQueenValue {
    /**
     * The Row assigned to the Queen
     **/
    public int row;

    public nQueenValue(int row) {
        this.row = row;
    }
}
