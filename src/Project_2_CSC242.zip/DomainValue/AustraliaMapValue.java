package DomainValue;

public enum AustraliaMapValue {
    /**
     * Color value for each Region
     **/
    Red, Green, Blue
}
