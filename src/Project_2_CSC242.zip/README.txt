*Personal Information:
- Name: Hoang Le
- UR ID: 31336536
- NetID: hle7
- Email: hle7@u.rochester.edu
* Collaborator:
- Name: Loc Bui
- URID: 31320986
- Email: lbui3@u.rochester.edu

*Instruction : Please build and run the project with terminal.

*How to Build the Project : javac Main.java
*How to Run the Project : java Main