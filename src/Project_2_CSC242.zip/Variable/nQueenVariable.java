package Variable;

public class nQueenVariable {
    /**
     * Initialize the Variable
     * Name and Index for the Queen
     **/
    public String name;
    public int index;

    public nQueenVariable(String name, int index) {
        this.name = name;
        this.index = index;
    }
}
