package Variable;

public class AustraliaMapVariable {
    /**
     * Initialize the Variable
     * Name for each Region
     **/
    public String name;

    public AustraliaMapVariable(String name) {
        this.name = name;
    }
}
